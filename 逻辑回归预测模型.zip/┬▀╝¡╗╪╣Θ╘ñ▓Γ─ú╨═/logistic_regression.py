import pandas as pd
import numpy as np
from sklearn import linear_model    # 调用sklearn的线性回归包
from sklearn.model_selection import train_test_split

df = pd.read_csv("logisticdata.csv", header=0)  # 加载数据集
df.dropna(how='any', inplace=True)      # 去掉缺失值
df.drop_duplicates(inplace=True)        # 删除重复值

x = df[['X0', 'X1']].values
y = df['Y'].values
# 划分训练集与测试集,
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)
print(x_train.shape, y_train.shape)

# Sigmoid 分布函数
def sigmoid(z):
    sigmoid = 1 / (1 + np.exp(-z))
    return sigmoid


# 损失函数
def loss(h, y):
    loss = (-y * np.log(h) - (1 - y) * np.log(1 - h)).mean()
    return loss


# 梯度计算
def gradient(X, h, y):
    gradient = np.dot(X.T, (h - y)) / y.shape[0]
    return gradient


# 逻辑回归过程
def Logistic_Regression(x, y, lr, num_iter):
    intercept = np.ones((x.shape[0], 1))  # 初始化截距为 1
    x = np.concatenate((intercept, x), axis=1)
    w = np.zeros(x.shape[1])  # 初始化参数为 0

    l_list = []  # 保存损失函数值
    for i in range(num_iter):  # 梯度下降迭代
        z = np.dot(x, w)  # 线性函数
        h = sigmoid(z)  # sigmoid 函数

        g = gradient(x, h, y)  # 计算梯度
        w -= lr * g  # 通过学习率 lr 计算步长并执行梯度下降

        z = np.dot(x, w)  # 更新参数到原线性函数中
        h = sigmoid(z)  # 计算 sigmoid 函数值

        l = loss(h, y)  # 计算损失函数值
        l_list.append(l)

    return l_list


# 设置参数并训练得到结果
lr = 0.00005  # 学习率
num_iter = 5000  # 迭代次数
l_y = Logistic_Regression(x, y, lr, num_iter)  # 训练
# print(l_y)

# 逻辑回归
es = linear_model.LogisticRegression()
es.fit(x_train, y_train)
print(es.predict(x_test))   # 预测测试集, 评估模型
print(es.score(x_test, y_test))
