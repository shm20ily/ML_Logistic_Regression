import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# 设置中文编码和负号的正常显示
plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'
plt.rcParams['axes.unicode_minus'] = False

df = pd.read_excel('数据.xlsx').set_index('年份')
# print(df)

# 数据清洗与特征分析
# 1、提取年份
year = df.index.tolist()[:: -1]
year = np.array(year)
print(year)

# 2、提取年产量中的数值
df['num'] = [re.findall(r'(\d+\.{0,1}\d*)', i)[0] for i in df['年产量']]
# 转化数值型
df['num'] = df['num'].astype('float')
# print(df['num'])
# 提取单位（万）
df['unit'] = [''.join(re.findall(r'(万)', i)) for i in df['年产量']]
df['unit'] = df['unit'].apply(lambda x: 10000 if x == '万' else 1)
# print(df['unit'])
# 计算年产量
df['年产量'] = df['num'] * df['unit']
p_out = df['年产量'].values.tolist()[:: -1]
p_out = np.array(p_out)
print(p_out)


# 建模分析与建立
def logistic_increase_function(t, K, P0, r):
    # t:time   t0:initial time    P0:initial_value    K:capacity  r:increase_rate
    t0 = 2015
    r = 0.65
    exp_value = np.exp(r * (t - t0))
    return (K * exp_value * P0) / (K + (exp_value - 1) * P0)


# 用最小二乘法估计拟合
popt, pcov = curve_fit(logistic_increase_function, year, p_out)
# 获取popt里面是拟合系数
print("K:capacity  P0:initial_value   r:increase_rate   t:time")
print(popt)

# print('*' * 80)
# 拟合后预测的预测值
p_predict = logistic_increase_function(year, popt[0], popt[1], popt[2])
print(p_predict)

print('*' * 80)
# 2023年石榴的年产量预测
next_year = [2023]
next_year = np.array(next_year)
next_predict = logistic_increase_function(next_year, popt[0], popt[1], popt[2])
print(f'2023年石榴的年产量为{next_predict[0]}吨')

# 可视化分析
plot1 = plt.plot(year, p_out, 's', label="2015-2022年石榴实际年产量")
plot2 = plt.plot(year, p_predict, 'r', label='2015-2022年石榴预测年产量')
plot3 = plt.plot(next_year, next_predict, 's', label='2023年石榴预测年产量')
plt.xlabel('年份')
plt.ylabel('2015-2023年曲靖会泽盐水石榴年产量趋势图')
# 指定legend的位置右下角
plt.legend(loc=0)
# plt.show()
