import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_curve, roc_auc_score
from sklearn import preprocessing
import warnings

warnings.filterwarnings('ignore')

# 加载数据
df = pd.read_csv('贷款客户数据.csv')
# 筛选数据————将Unnamed: 0, 'RowNumber', 'CustomerId', 'Surname'这三列删除
df.drop(['Unnamed: 0', 'RowNumber', 'CustomerId', 'Surname'], axis=1, inplace=True)

# 将Gender列的字符串类型映射为数值型表示
Gender_dict = {"Female": 0, "Male": 1}
df["Gender"] = df["Gender"].map(Gender_dict)
# 查看前5行数据
# print(df.head())

# 划分特征变量与目标变量
X = df.iloc[:, :-1]     # 特征变量为前5列
Y = df.iloc[:, -1]      # 目标变量为最后1列

# 数据标准化处理
X = preprocessing.StandardScaler().fit_transform(X)

# 分别查看X、Y的前5行数据
# print(X.head())
# print(Y.head())

# 划分训练集与测试集，训练集为0.8， 测试集为0.2
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=1)    # random_state为固定样本不变

# # 查看训练集与测试集的形状
# print(x_train.shape)
# print(x_test.shape)
# print(y_train.shape)
# print(y_test.shape)

# 建立模型
model = LogisticRegression(solver='newton-cg', multi_class='multinomial')
# 训练模型
model.fit(x_train, y_train)
print(model)

# 预测测试集分类结果
y_pred = model.predict(x_test)
# 输出前20个预测的目标
# print(y_pred[:20])

# 使用DataFrame形式展示
a = pd.DataFrame()
a['预测值'] = list(y_pred)
a['真实值'] = list(y_test)
# 查看前5个以及后5个
# print(a.head())
# print(a.tail())

# 计算准确率
accuracy = accuracy_score(y_test, y_pred)
print(accuracy)
# 使用模型自带的score()函数来计算预测准确度
score = model.score(x_test, y_test)
print(score)

# 预测概率
y_pred_proba = model.predict_proba(x_test)
# 查看结果的前5项
# print(y_pred_proba[:5])

# 使用DataFrame形式展示
proba = pd.DataFrame(y_pred_proba, columns=['不贷款概率', '贷款概率'])
# 查看前5个以及后5个
# print(proba.head())
# print(proba.tail())

# 混淆矩阵
x = confusion_matrix(y_test, y_pred)
# print(x)
# 使用DataFrame形式展示
y = pd.DataFrame(x, index=['0实际不贷款', '1实际贷款'], columns=['0预测不贷款', '1预测贷款'])
# print(y)

# 求出不同阈值下的命中率（TPR）和假警报率（FPR）的值
fpr, tpr, thres = roc_curve(y_test, y_pred_proba[:, 1])

# 求出模型的AUC值
auc = roc_auc_score(y_test, y_pred_proba[:, 1])
print('AUC值：', auc)

# 求KS值————使用KS值来衡量模型预测效果
ks = max(tpr - fpr)
print('KS值：', ks)
