import pandas as pd

# 读取数据
df_train = pd.read_csv("train.csv")
df_test = pd.read_csv("test.csv")

'''a.说明如何处理代码中缺失的值并报告结果'''
# df_train.info()  # 检测数据
df_train.isnull().sum()  # 通过 isnull() 函数查找缺失值个数
df_train.dropna(inplace=True)  # 方案一：删除所有缺失值
df_train.fillna(0, inplace=True)  # 方案二：用0填充所有缺失值
# 统计0数值个数:(df == 0).sum(axis=1) / df.apply(lambda x: x.value_counts().get(0, 0), axis=0)
df_train.apply(lambda x: x.value_counts().get(0, 0), axis=0)  # 统计每一列0数值的个数

# df_test.info()
df_test.isnull().sum()  # 通过 isnull() 函数查找缺失值个数
df_test.dropna(inplace=True)  # 方案一：删除所有缺失值
df_test.fillna(0, inplace=True)  # 方案二：用0填充所有缺失值
df_test.apply(lambda x: x.value_counts().get(0, 0), axis=0)  # 统计每一列0数值的个数

# 数据切分——分别获取训练集特征与标签、测试集特征与标签
x_train, y_train = df_train['LotArea'].values.reshape((-1, 1)), df_train['SalePrice'].values
x_test, y_test = df_test['LotArea'].values.reshape((-1, 1)), df_test['SalePrice'].values


from sklearn.linear_model import Ridge, LinearRegression, Lasso
from sklearn.metrics import mean_squared_error
import numpy as np
import matplotlib.pyplot as plt

# 设置中文编码和负号的正常显示
plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'
plt.rcParams['axes.unicode_minus'] = False


'''基于方案二：用0填充所有缺失值'''
'''b.对您所使用的回归技术的描述'''
# 创建岭回归模型
es = Ridge()
# 进行模型拟合
es.fit(x_train, y_train)
# 进行模型预测
y_pred = es.predict(x_test)
# 进行模型评估  真实值 预测值
print('Ridge RMSE =', np.sqrt(mean_squared_error(y_test, y_pred)))

'''c.对要报告的结果的描述'''
# 可视化
# 绘制测试集真实值的散点图
plt.scatter(x_test, y_test, color="darkgreen", alpha=0.1)
# 绘制测试集预测值的拟合线
plt.plot(x_test, y_pred, color="red")
plt.xlabel("地块面积")
plt.ylabel("销售价格")
plt.show()

'''b.对您所使用的回归技术的描述'''
# 线性回归模型
# model = LinearRegression()
model = Lasso()
model.fit(x_train, y_train)
pred = model.predict(x_test)
print('LinearRegression RMSE =', np.sqrt(mean_squared_error(y_test, pred)))

'''c.对要报告的结果的描述'''
# 绘制测试集真实值的散点图
plt.scatter(x_test, y_test, color="darkgreen", alpha=0.1)
# 绘制测试集预测值的拟合线
plt.plot(x_test, pred, color="gray")
plt.xlabel("地块面积")
plt.ylabel("销售价格")
plt.show()
